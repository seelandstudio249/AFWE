using Dissonance.Editor;

namespace Dissonance.Integrations.FishNet.Editor
{
    // Editor script for Dissonance Voice Player
    public class DissonanceFishNetPlayerEditor : BaseIDissonancePlayerEditor { }
}